import pandas as pd


def validate_data(df):

    errors = []

    # ==================================================
    # 1. CHECK MISSING VALUES
    # ==================================================

    missing_values = df.isnull().sum()

    for column, count in missing_values.items():

        if count > 0:

            errors.append(
                f"{column} has {count} missing value(s)"
            )


    # ==================================================
    # 2. CHECK DUPLICATE ROWS
    # ==================================================

    duplicate_count = df.duplicated().sum()

    if duplicate_count > 0:

        errors.append(
            f"Found {duplicate_count} duplicate row(s)"
        )


    # ==================================================
    # 3. CHECK NEGATIVE QUANTITY
    # ==================================================

    if "quantity" in df.columns:

        if (df["quantity"] < 0).any():

            errors.append(
                "Negative quantity found"
            )


    # ==================================================
    # 4. CHECK NEGATIVE AMOUNT
    # ==================================================

    if "amount" in df.columns:

        if (df["amount"] < 0).any():

            errors.append(
                "Negative amount found"
            )


    # ==================================================
    # 5. VALIDATION RESULT
    # ==================================================

    if errors:

        return {
            "valid": False,
            "errors": errors
        }


    return {
        "valid": True,
        "errors": []
    }