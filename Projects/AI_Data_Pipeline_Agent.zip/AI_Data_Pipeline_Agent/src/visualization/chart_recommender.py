import os
import json
from dotenv import load_dotenv
from google import genai



load_dotenv()

api_key = os.getenv("GEMINI_API_KEY")

if not api_key:
    raise ValueError("GEMINI_API_KEY not found in .env")

client = genai.Client(api_key=api_key)


def recommend_charts(df):
    """
    Ask Gemini to recommend useful visualizations
    based on the uploaded dataset.
    """

    # Get dataset information
    columns = []

    for column in df.columns:
        columns.append({
            "name": str(column),
            "data_type": str(df[column].dtype),
            "unique_values": int(df[column].nunique())
        })

    dataset_info = {
        "rows": len(df),
        "columns": columns
    }

    prompt = f"""
You are an expert Data Analyst.

Analyze this dataset information:

{json.dumps(dataset_info, indent=2)}

Recommend the most useful visualizations for this dataset.

Rules:

1. Recommend 3 to 6 charts.
2. Use ONLY columns that actually exist.
3. Do not invent column names.
4. Choose charts based on the data types.
5. Use bar charts for category comparisons.
6. Use line charts for time-based trends.
7. Use scatter plots for relationships between numerical columns.
8. Use histograms for numerical distributions.
9. Use pie charts only when there are a small number of categories.
10. Avoid unnecessary charts.
11. Give each chart a meaningful title.
12. Explain briefly why each chart is useful.

Return ONLY valid JSON in this exact format:

[
    {{
        "chart_type": "bar",
        "title": "Sales by Region",
        "x_column": "Region",
        "y_column": "Sales",
        "reason": "Shows total sales for each region."
    }}
]

Allowed chart_type values:

bar
line
scatter
histogram
pie

For histogram:
- x_column is required
- y_column must be null

For pie:
- x_column is the category
- y_column is the numerical value

For scatter:
- x_column is one numerical column
- y_column is another numerical column
"""

    response = client.interactions.create(
        model="gemini-3.6-flash",
        input=prompt
    )

    result = response.output_text.strip()

    # Remove markdown code blocks if Gemini adds them
    if result.startswith("```"):
        result = result.replace("```json", "")
        result = result.replace("```", "")
        result = result.strip()

    try:
        recommendations = json.loads(result)
    except json.JSONDecodeError:
        return []

    return recommendations
import plotly.express as px
import streamlit as st


def display_recommended_charts(df, recommendations):
    """
    Create and display charts recommended by Gemini.
    """

    st.subheader("📊 AI Recommended Visualizations")

    for chart in recommendations:

        chart_type = chart.get("chart_type")
        title = chart.get("title", "Recommended Chart")
        x_column = chart.get("x_column")
        y_column = chart.get("y_column")

        # Check that columns actually exist
        if x_column and x_column not in df.columns:
            continue

        if y_column and y_column not in df.columns:
            continue

        try:

            if chart_type == "bar":

                fig = px.bar(
                    df,
                    x=x_column,
                    y=y_column,
                    title=title
                )

            elif chart_type == "line":

                fig = px.line(
                    df,
                    x=x_column,
                    y=y_column,
                    title=title
                )

            elif chart_type == "scatter":

                fig = px.scatter(
                    df,
                    x=x_column,
                    y=y_column,
                    title=title
                )

            elif chart_type == "histogram":

                fig = px.histogram(
                    df,
                    x=x_column,
                    title=title
                )

            elif chart_type == "pie":

                fig = px.pie(
                    df,
                    names=x_column,
                    values=y_column,
                    title=title
                )

            else:
                continue

            st.plotly_chart(
                fig,
                use_container_width=True
            )

            reason = chart.get("reason")

            if reason:
                st.caption(f"💡 {reason}")

        except Exception as e:
            st.warning(
                f"Could not create '{title}': {e}"
            )