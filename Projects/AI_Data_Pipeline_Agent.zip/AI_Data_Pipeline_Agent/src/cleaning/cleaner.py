import pandas as pd


def clean_data(df):
    # Remove duplicate rows
    df = df.drop_duplicates()

    # Fill missing customer names
    df["customer_name"] = df["customer_name"].fillna("Unknown")

    # Convert order_date to datetime
    df["order_date"] = pd.to_datetime(df["order_date"])

    return df


if __name__ == "__main__":
    df = pd.read_csv("data/orders.csv")

    print("Before cleaning:")
    print(df)

    df = clean_data(df)

    print("\nAfter cleaning:")
    print(df)
