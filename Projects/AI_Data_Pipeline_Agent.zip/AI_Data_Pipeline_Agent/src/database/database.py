from sqlalchemy import create_engine

DATABASE_URL = "postgresql://postgres:Imam%409197@localhost:5432/ai_data_pipeline"

engine = create_engine(DATABASE_URL)