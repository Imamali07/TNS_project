import pandas as pd
from database import engine

# Load CSV
df = pd.read_csv("data/orders.csv")

# Clean data
df = df.drop_duplicates()
df["customer_name"] = df["customer_name"].fillna("Unknown")
df["order_date"] = pd.to_datetime(df["order_date"])

# Insert into PostgreSQL
df.to_sql(
    "orders",
    engine,
    if_exists="replace",
    index=False
)

print("Data inserted into PostgreSQL successfully!")