from src.database.database import engine


def save_to_database(df, table_name="orders"):
    """
    Save a Pandas DataFrame to PostgreSQL.

    Parameters:
        df: Pandas DataFrame
        table_name: PostgreSQL table name

    Returns:
        str: Name of the table where data was saved
    """

    df.to_sql(
        table_name,
        engine,
        if_exists="replace",
        index=False
    )

    return table_name