import os
import re

from dotenv import load_dotenv
from google import genai
from sqlalchemy import text

from src.database.database import engine


# ============================================================
# 1. LOAD ENVIRONMENT VARIABLES
# ============================================================

load_dotenv()

api_key = os.getenv("GEMINI_API_KEY")

if not api_key:
    raise ValueError(
        "GEMINI_API_KEY not found in .env"
    )


# ============================================================
# 2. GEMINI CLIENT
# ============================================================

client = genai.Client(
    api_key=api_key
)


# ============================================================
# 3. GET DATABASE SCHEMA
# ============================================================

def get_database_schema(table_name="orders"):
    query = """
    SELECT
        column_name,
        data_type
    FROM information_schema.columns
    WHERE table_name = :table_name
    ORDER BY ordinal_position;
    """

    with engine.connect() as connection:
        result = connection.execute(
            text(query),
            {"table_name": table_name}
        )
        columns = result.fetchall()

    return columns


# ============================================================
# 4. FORMAT DATABASE SCHEMA
# ============================================================

def format_schema(table_name="orders"):
    schema = get_database_schema(table_name)

    if not schema:
        return f"No '{table_name}' table found."

    schema_text = f"Table: {table_name}\n\nColumns:\n"

    for column, data_type in schema:
        schema_text += f"- {column} ({data_type})\n"

    return schema_text


# ============================================================
# 5. GENERATE SQL USING GEMINI
# ============================================================

def generate_sql(question, table_name="orders"):

    schema = format_schema(table_name)

    prompt = f"""
You are an expert PostgreSQL SQL analyst.

The database contains a table called "{table_name}".

Here is the ACTUAL database schema:

{schema}

The user asked:

{question}

Your task is to generate ONE PostgreSQL SELECT query
that answers the user's exact question.

IMPORTANT RULES:

1. Use ONLY columns that actually exist in the schema.
2. NEVER invent a column.
3. Understand the meaning of the user's question.
4. Do not change the meaning of the question.
5. If the user asks for a total number of records,
   use COUNT(*).
6. If the user asks for an average, use AVG().
7. If the user asks for a total, use SUM() when appropriate.
8. If the user asks for the highest value, use MAX()
   or ORDER BY ... DESC LIMIT 1.
9. If the user asks for the lowest value, use MIN()
   or ORDER BY ... ASC LIMIT 1.
10. If the user asks for groups or categories,
    use GROUP BY.
11. Use appropriate WHERE conditions.
12. Use only SELECT.
13. Never use INSERT.
14. Never use UPDATE.
15. Never use DELETE.
16. Never use DROP.
17. Never use ALTER.
18. Never use CREATE.
19. Never use TRUNCATE.
20. Never use GRANT.
21. Never use REVOKE.
22. Do not modify the database.
23. Return ONLY the SQL query.
24. Do not use markdown code blocks.

IMPORTANT FOR COLUMN NAMES:

If a column name contains spaces, punctuation,
question marks, or other special characters,
use double quotes around the column name.

Example:

SELECT COUNT(DISTINCT "What are your savings objectives?")
FROM orders;

If the question cannot be answered using the available
columns, return exactly:

CANNOT_ANSWER
"""

    response = client.interactions.create(
        model="gemini-3.6-flash",
        input=prompt
    )

    sql = response.output_text.strip()

    # Remove markdown code blocks if Gemini adds them
    sql = re.sub(
        r"```sql\s*",
        "",
        sql,
        flags=re.IGNORECASE
    )

    sql = re.sub(
        r"```\s*$",
        "",
        sql
    )

    return sql.strip()


# ============================================================
# 6. SQL SAFETY CHECK
# ============================================================

def is_safe_sql(sql):

    sql = sql.strip()

    sql_upper = sql.upper()

    # Must start with SELECT
    if not sql_upper.startswith("SELECT"):

        return False


    # Block multiple SQL statements
    if ";" in sql[:-1]:

        return False


    # Block SQL comments
    if "--" in sql:

        return False


    if "/*" in sql or "*/" in sql:

        return False


    dangerous_commands = [
        "INSERT",
        "UPDATE",
        "DELETE",
        "DROP",
        "ALTER",
        "CREATE",
        "TRUNCATE",
        "GRANT",
        "REVOKE"
    ]


    for command in dangerous_commands:

        if re.search(
            rf"\b{command}\b",
            sql_upper
        ):

            return False


    return True


# ============================================================
# 7. RUN SQL QUERY
# ============================================================

def run_sql(query):
    with engine.connect() as connection:
        result = connection.execute(text(query))
        rows = result.fetchall()
        columns = list(result.keys())

    return columns, rows


# ============================================================
# 8. FORMAT DATABASE RESULT
# ============================================================

def format_result(columns, rows):

    if not rows:

        return "The query returned no results."


    result_text = ""

    for row in rows:

        row_data = []

        for column, value in zip(
            columns,
            row
        ):

            row_data.append(
                f"{column}: {value}"
            )

        result_text += (
            ", ".join(row_data)
            + "\n"
        )


    return result_text.strip()


# ============================================================
# 9. GENERATE FINAL HUMAN-READABLE ANSWER
# ============================================================

def generate_answer(
    question,
    sql,
    result_text
):

    prompt = f"""
You are an AI Data Analyst.

The user asked this exact question:

{question}

The SQL query executed was:

{sql}

The database returned:

{result_text}

Give the user a direct, accurate, simple answer.

IMPORTANT RULES:

1. Answer the user's EXACT question.
2. Do not change the meaning of the question.
3. Use the database result as the source of truth.
4. Do not invent information.
5. Do not invent columns.
6. Do not invent values.
7. Do not invent statistics.
8. Do not unnecessarily say that the question cannot be answered.
9. If the SQL result directly answers the question,
   give that answer clearly.
10. If the user asks "How many people are in the dataset?"
    and the result is "count: 40",
    answer:
    "There are 40 people in the dataset."
11. Do not call the records "orders" just because
    the PostgreSQL table is named "orders".
12. Follow the user's wording.
13. If the user asks for an average, clearly state the average.
14. If the user asks for a count, clearly state the count.
15. If the user asks for a total, clearly state the total.
16. If the user asks for a comparison, explain the comparison.
17. If the user asks for grouped results, summarize the groups.
18. If the database result genuinely does not contain enough
    information to answer the question, say that clearly.
19. Keep the answer concise and easy to understand.
20. Do not mention the SQL query unless necessary.
21. Return ONLY the final answer.

Examples:

Example 1

User question:
How many people are in the dataset?

Database result:
count: 40

Answer:
There are 40 people in the dataset.


Example 2

User question:
What is the average age?

Database result:
avg: 28.5

Answer:
The average age is 28.5 years.


Example 3

User question:
How many males are there?

Database result:
count: 18

Answer:
There are 18 males in the dataset.


Example 4

User question:
What is the average salary?

Database result:
No salary column exists.

Answer:
The dataset does not contain salary information,
so I cannot calculate the average salary.
"""

    response = client.interactions.create(
        model="gemini-3.6-flash",
        input=prompt
    )

    return response.output_text.strip()


# ============================================================
# 10. MAIN SQL AGENT
# ============================================================

def sql_agent(question, table_name="orders"):

    try:

        # ----------------------------------------------------
        # Generate SQL
        # ----------------------------------------------------

        sql = generate_sql(question, table_name)

        print("\nGenerated SQL:")
        print(sql)


        # ----------------------------------------------------
        # Check whether question can be answered
        # ----------------------------------------------------

        if sql == "CANNOT_ANSWER":

            return (
                "I cannot answer this question because "
                "the required information is not available "
                "in the current dataset."
            )


        # ----------------------------------------------------
        # Safety check
        # ----------------------------------------------------

        if not is_safe_sql(sql):

            return (
                "❌ The generated SQL query was blocked "
                "for safety reasons."
            )


        # ----------------------------------------------------
        # Execute SQL
        # ----------------------------------------------------

        columns, rows = run_sql(
            sql
        )


        # ----------------------------------------------------
        # Format result
        # ----------------------------------------------------

        result_text = format_result(
            columns,
            rows
        )

        print("\nDatabase Result:")
        print(result_text)


        # ----------------------------------------------------
        # Generate final answer
        # ----------------------------------------------------

        answer = generate_answer(
            question,
            sql,
            result_text
        )


        return answer


    except Exception as e:

        return (
            "❌ Unable to answer the question.\n\n"
            f"Error: {e}"
        )


# ============================================================
# 11. TEST THE SQL AGENT
# ============================================================

if __name__ == "__main__":

    print(
        "🤖 AI Data Analyst SQL Agent"
    )

    print(
        "================================"
    )


    # --------------------------------------------------------
    # Display current schema
    # --------------------------------------------------------

    print(
        "\n📋 Current Database Schema:"
    )

    print(
        format_schema()
    )


    # --------------------------------------------------------
    # Ask user question
    # --------------------------------------------------------

    question = input(
        "\nAsk a question about your dataset: "
    )


    # --------------------------------------------------------
    # Run SQL Agent
    # --------------------------------------------------------

    answer = sql_agent(
        question
    )


    # --------------------------------------------------------
    # Display final answer
    # --------------------------------------------------------

    print(
        "\nAnswer:"
    )

    print(
        answer
    )