import pandas as pd


def load_csv(file_path):
    df = pd.read_csv(file_path)
    return df


if __name__ == "__main__":
    file_path = "data/orders.csv"

    df = load_csv(file_path)

    print("Data loaded successfully!")
    print(df)
