import sys
from pathlib import Path

# ==================================================
# PROJECT PATH
# ==================================================

PROJECT_ROOT = Path(__file__).resolve().parent.parent

if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))


# ==================================================
# IMPORTS
# ==================================================

import streamlit as st
import pandas as pd

from src.database.upload_data import save_to_database
from src.validation.validator import validate_data
from src.agents.sql_agent import sql_agent

from src.visualization.chart_recommender import (
    recommend_charts,
    display_recommended_charts
)


# ==================================================
# PAGE CONFIG
# ==================================================

st.set_page_config(
    page_title="AI Data Pipeline Agent",
    page_icon="🤖",
    layout="wide"
)


# ==================================================
# SESSION STATE
# ==================================================

if "df" not in st.session_state:
    st.session_state.df = None

if "analyzed" not in st.session_state:
    st.session_state.analyzed = False

if "cleaned" not in st.session_state:
    st.session_state.cleaned = False

if "file_id" not in st.session_state:
    st.session_state.file_id = None

if "database_saved" not in st.session_state:
    st.session_state.database_saved = False

if "table_name" not in st.session_state:
    st.session_state.table_name = "orders"

if "chart_recommendations" not in st.session_state:
    st.session_state.chart_recommendations = []


# ==================================================
# TITLE
# ==================================================

st.title("🤖 AI Data Pipeline Agent")

st.write(
    "Upload your CSV or Excel file to analyze, "
    "clean, validate and ask questions using AI."
)


# ==================================================
# FILE UPLOAD
# ==================================================

uploaded_file = st.file_uploader(
    "Upload your dataset",
    type=["csv", "xlsx"]
)


# ==================================================
# AI RECOMMENDATION FOR MISSING VALUES
# ==================================================

def get_missing_recommendation(df, column):

    if pd.api.types.is_numeric_dtype(df[column]):

        median_value = df[column].median()
        mean_value = df[column].mean()

        return (
            f"Numeric column. Recommended: fill with "
            f"median ({median_value:.2f}). "
            f"Mean is {mean_value:.2f}."
        )

    elif pd.api.types.is_datetime64_any_dtype(df[column]):

        return (
            "Date column. Recommended: review the "
            "missing records before filling."
        )

    else:

        mode = df[column].mode()

        if len(mode) > 0:

            return (
                f"Text/category column. Recommended: fill with "
                f"the most frequent value '{mode.iloc[0]}'."
            )

        return "Review the missing records."


# ==================================================
# CLEANING FUNCTION
# ==================================================

def clean_data(df):

    cleaned_df = df.copy()

    cleaning_summary = []


    # ==================================================
    # MISSING VALUES
    # ==================================================

    missing = cleaned_df.isnull().sum()

    missing = missing[missing > 0]


    for column in missing.index:

        action = st.session_state.get(
            f"missing_action_{column}",
            "Keep unchanged"
        )

        original_missing = cleaned_df[column].isnull().sum()


        # ----------------------------------------------
        # FILL WITH MEDIAN
        # ----------------------------------------------

        if action == "Fill with median":

            if pd.api.types.is_numeric_dtype(
                cleaned_df[column]
            ):

                median_value = cleaned_df[column].median()

                cleaned_df[column] = cleaned_df[column].fillna(
                    median_value
                )

                cleaning_summary.append(
                    f"{column}: {original_missing} missing "
                    f"value(s) filled with median "
                    f"({median_value:.2f})"
                )


        # ----------------------------------------------
        # FILL WITH MEAN
        # ----------------------------------------------

        elif action == "Fill with mean":

            if pd.api.types.is_numeric_dtype(
                cleaned_df[column]
            ):

                mean_value = cleaned_df[column].mean()

                cleaned_df[column] = cleaned_df[column].fillna(
                    mean_value
                )

                cleaning_summary.append(
                    f"{column}: {original_missing} missing "
                    f"value(s) filled with mean "
                    f"({mean_value:.2f})"
                )


        # ----------------------------------------------
        # FILL WITH MOST FREQUENT
        # ----------------------------------------------

        elif action == "Fill with most frequent value":

            mode = cleaned_df[column].mode()

            if len(mode) > 0:

                mode_value = mode.iloc[0]

                cleaned_df[column] = cleaned_df[column].fillna(
                    mode_value
                )

                cleaning_summary.append(
                    f"{column}: {original_missing} missing "
                    f"value(s) filled with "
                    f"'{mode_value}'"
                )


        # ----------------------------------------------
        # FILL WITH UNKNOWN
        # ----------------------------------------------

        elif action == 'Fill with "Unknown"':

            cleaned_df[column] = cleaned_df[column].fillna(
                "Unknown"
            )

            cleaning_summary.append(
                f'{column}: {original_missing} missing '
                f'value(s) filled with "Unknown"'
            )


        # ----------------------------------------------
        # REMOVE ROWS
        # ----------------------------------------------

        elif action == "Remove rows":

            before = len(cleaned_df)

            cleaned_df = cleaned_df.dropna(
                subset=[column]
            )

            removed = before - len(cleaned_df)

            cleaning_summary.append(
                f"{column}: {removed} row(s) removed"
            )


        # ----------------------------------------------
        # REVIEW RECORDS
        # ----------------------------------------------

        elif action == "Review records":

            cleaning_summary.append(
                f"{column}: kept unchanged for review"
            )


        # ----------------------------------------------
        # KEEP UNCHANGED
        # ----------------------------------------------

        elif action == "Keep unchanged":

            cleaning_summary.append(
                f"{column}: kept unchanged"
            )


    # ==================================================
    # DUPLICATES
    # ==================================================

    duplicate_action = st.session_state.get(
        "duplicate_action",
        "Keep them unchanged"
    )

    duplicate_before = cleaned_df.duplicated().sum()


    # ----------------------------------------------
    # REMOVE ALL DUPLICATES
    # ----------------------------------------------

    if duplicate_action == "Remove all duplicate rows":

        cleaned_df = cleaned_df.drop_duplicates()

        cleaning_summary.append(
            f"{duplicate_before} duplicate row(s) removed"
        )


    # ----------------------------------------------
    # KEEP FIRST
    # ----------------------------------------------

    elif duplicate_action == "Keep first occurrence":

        cleaned_df = cleaned_df.drop_duplicates(
            keep="first"
        )

        cleaning_summary.append(
            f"{duplicate_before} duplicate row(s) handled "
            f"(kept first occurrence)"
        )


    # ----------------------------------------------
    # KEEP LAST
    # ----------------------------------------------

    elif duplicate_action == "Keep last occurrence":

        cleaned_df = cleaned_df.drop_duplicates(
            keep="last"
        )

        cleaning_summary.append(
            f"{duplicate_before} duplicate row(s) handled "
            f"(kept last occurrence)"
        )


    # ----------------------------------------------
    # REVIEW DUPLICATES
    # ----------------------------------------------

    elif duplicate_action == "Review duplicate records":

        cleaning_summary.append(
            "Duplicate records kept for review"
        )


    # ----------------------------------------------
    # KEEP DUPLICATES UNCHANGED
    # ----------------------------------------------

    else:

        cleaning_summary.append(
            "Duplicate records kept unchanged"
        )


    return cleaned_df, cleaning_summary


# ==================================================
# PROCESS UPLOADED FILE
# ==================================================

if uploaded_file is not None:

    try:

        # ==================================================
        # FILE ID
        # ==================================================

        current_file_id = (
            uploaded_file.name,
            uploaded_file.size
        )


        # ==================================================
        # LOAD NEW FILE
        # ==================================================

        if current_file_id != st.session_state.file_id:

            if uploaded_file.name.lower().endswith(".csv"):

                df = pd.read_csv(uploaded_file)

            else:

                df = pd.read_excel(uploaded_file)


            # Save original dataframe
            st.session_state.df = df.copy()

            # Save file information
            st.session_state.file_id = current_file_id

            # Reset workflow states
            st.session_state.analyzed = False
            st.session_state.cleaned = False
            st.session_state.database_saved = False

            # Reset table name
            st.session_state.table_name = "orders"

            # IMPORTANT:
            # Clear old AI chart recommendations
            st.session_state.chart_recommendations = []


        # ==================================================
        # GET DATAFRAME
        # ==================================================

        df = st.session_state.df


        # ==================================================
        # FILE SUCCESS
        # ==================================================

        st.success(
            f"✅ File uploaded: {uploaded_file.name}"
        )


        # ==================================================
        # DATASET PREVIEW
        # ==================================================

        st.subheader("📊 Dataset Preview")

        st.dataframe(
            df,
            use_container_width=True
        )


        # ==================================================
        # BASIC INFORMATION
        # ==================================================

        col1, col2 = st.columns(2)

        with col1:

            st.metric(
                "Total Rows",
                len(df)
            )

        with col2:

            st.metric(
                "Total Columns",
                len(df.columns)
            )


        st.divider()


        # ==================================================
        # ANALYZE DATASET
        # ==================================================

        if st.button(
            "🔍 Analyze Dataset",
            type="primary"
        ):

            st.session_state.analyzed = True

            st.session_state.cleaned = False

            st.session_state.database_saved = False


        # ==================================================
        # DATA QUALITY REPORT
        # ==================================================

        if st.session_state.analyzed:

            st.subheader(
                "📋 Data Quality Report"
            )


            # ==================================================
            # MISSING VALUES
            # ==================================================

            missing = df.isnull().sum()

            missing = missing[missing > 0]


            if len(missing) > 0:

                st.warning(
                    "⚠️ Missing values found"
                )


                for column, count in missing.items():

                    st.write(
                        f"**{column}** → "
                        f"{count} missing value(s)"
                    )


                    # ------------------------------------------
                    # AI RECOMMENDATION
                    # ------------------------------------------

                    recommendation = (
                        get_missing_recommendation(
                            df,
                            column
                        )
                    )


                    st.info(
                        f"🤖 AI Recommendation: "
                        f"{recommendation}"
                    )


                    # ------------------------------------------
                    # NUMERIC COLUMN
                    # ------------------------------------------

                    if pd.api.types.is_numeric_dtype(
                        df[column]
                    ):

                        options = [
                            "Fill with median",
                            "Fill with mean",
                            "Remove rows",
                            "Review records",
                            "Keep unchanged"
                        ]


                    # ------------------------------------------
                    # DATE COLUMN
                    # ------------------------------------------

                    elif pd.api.types.is_datetime64_any_dtype(
                        df[column]
                    ):

                        options = [
                            "Remove rows",
                            "Review records",
                            "Keep unchanged"
                        ]


                    # ------------------------------------------
                    # TEXT COLUMN
                    # ------------------------------------------

                    else:

                        options = [
                            "Fill with most frequent value",
                            'Fill with "Unknown"',
                            "Remove rows",
                            "Review records",
                            "Keep unchanged"
                        ]


                    # ------------------------------------------
                    # USER ACTION
                    # ------------------------------------------

                    st.selectbox(
                        f"What should I do with missing values in {column}?",
                        options,
                        key=f"missing_action_{column}"
                    )


                    # ------------------------------------------
                    # REVIEW MISSING RECORDS
                    # ------------------------------------------

                    if st.session_state.get(
                        f"missing_action_{column}"
                    ) == "Review records":

                        st.write(
                            f"Records with missing "
                            f"**{column}**:"
                        )

                        st.dataframe(
                            df[df[column].isnull()],
                            use_container_width=True
                        )


            else:

                st.success(
                    "✅ No missing values found"
                )


            # ==================================================
            # DUPLICATES
            # ==================================================

            duplicate_count = df.duplicated().sum()


            if duplicate_count > 0:

                st.warning(
                    f"⚠️ Found {duplicate_count} "
                    f"duplicate row(s)"
                )


                st.selectbox(
                    "What should I do with duplicate rows?",
                    [
                        "Remove all duplicate rows",
                        "Keep first occurrence",
                        "Keep last occurrence",
                        "Review duplicate records",
                        "Keep them unchanged"
                    ],
                    key="duplicate_action"
                )


                # ------------------------------------------
                # REVIEW DUPLICATES
                # ------------------------------------------

                if st.session_state.get(
                    "duplicate_action"
                ) == "Review duplicate records":

                    st.write(
                        "Duplicate records:"
                    )

                    st.dataframe(
                        df[df.duplicated(keep=False)],
                        use_container_width=True
                    )


            else:

                st.success(
                    "✅ No duplicate rows found"
                )


            # ==================================================
            # DATA TYPES
            # ==================================================

            st.subheader(
                "🔤 Column Data Types"
            )


            dtype_df = pd.DataFrame({
                "Column": df.columns,
                "Data Type": df.dtypes.astype(str).values
            })


            st.dataframe(
                dtype_df,
                use_container_width=True
            )


            st.divider()


            # ==================================================
            # APPLY CLEANING
            # ==================================================

            if st.button(
                "🧹 Apply Cleaning",
                type="primary"
            ):

                # ------------------------------------------
                # CLEAN
                # ------------------------------------------

                cleaned_df, summary = clean_data(df)


                # ------------------------------------------
                # SAVE CLEANED DATA IN SESSION
                # ------------------------------------------

                st.session_state.df = cleaned_df.copy()

                st.session_state.cleaned = True

                st.session_state.database_saved = False

                # New cleaned data means old chart
                # recommendations are no longer valid
                st.session_state.chart_recommendations = []


                # ------------------------------------------
                # CLEANING SUCCESS
                # ------------------------------------------

                st.success(
                    "✅ Cleaning completed successfully!"
                )


                # ==================================================
                # CLEANING SUMMARY
                # ==================================================

                st.subheader(
                    "🧹 Cleaning Summary"
                )


                for item in summary:

                    st.write(
                        f"• {item}"
                    )


                # ==================================================
                # SHOW CLEANED DATA
                # ==================================================

                st.subheader(
                    "✨ Cleaned Dataset"
                )


                st.dataframe(
                    cleaned_df,
                    use_container_width=True
                )


                # ==================================================
                # VALIDATE CLEANED DATA
                # ==================================================

                st.subheader(
                    "🔍 Data Validation"
                )


                validation_result = validate_data(
                    cleaned_df
                )


                if validation_result["valid"]:

                    st.success(
                        "✅ Data validation passed!"
                    )


                    # ------------------------------------------
                    # SAVE TO POSTGRESQL
                    # ------------------------------------------

                    try:

                        # Create table name from uploaded file
                        table_name = uploaded_file.name.rsplit(
                            ".",
                            1
                        )[0]

                        # Make table name PostgreSQL-friendly
                        table_name = (
                            table_name
                            .lower()
                            .replace(" ", "_")
                            .replace("-", "_")
                        )

                        save_to_database(
                            cleaned_df,
                            table_name
                        )


                        # Store current table name
                        st.session_state.database_saved = True

                        st.session_state.table_name = table_name


                        st.success(
                            "🗄️ Cleaned and validated data "
                            "saved to PostgreSQL successfully!"
                        )


                    except Exception as db_error:

                        st.session_state.database_saved = False

                        st.error(
                            "❌ Could not save data to PostgreSQL."
                        )

                        st.exception(
                            db_error
                        )


                else:

                    st.session_state.database_saved = False

                    st.error(
                        "❌ Data validation failed!"
                    )

                    st.warning(
                        "⚠️ Data was NOT saved to PostgreSQL."
                    )


                    # ------------------------------------------
                    # SHOW VALIDATION ERRORS
                    # ------------------------------------------

                    st.write(
                        "Validation errors:"
                    )


                    for error in validation_result["errors"]:

                        st.write(
                            f"❌ {error}"
                        )


                # ==================================================
                # REMAINING PROBLEMS
                # ==================================================

                st.subheader(
                    "📊 Final Data Quality"
                )


                remaining_missing = (
                    cleaned_df.isnull().sum().sum()
                )


                remaining_duplicates = (
                    cleaned_df.duplicated().sum()
                )


                col1, col2 = st.columns(2)


                # ------------------------------------------
                # MISSING VALUES
                # ------------------------------------------

                with col1:

                    if remaining_missing == 0:

                        st.success(
                            "✅ No missing values remain"
                        )

                    else:

                        st.warning(
                            f"⚠️ {remaining_missing} "
                            f"missing value(s) remain"
                        )


                # ------------------------------------------
                # DUPLICATES
                # ------------------------------------------

                with col2:

                    if remaining_duplicates == 0:

                        st.success(
                            "✅ No duplicate rows remain"
                        )

                    else:

                        st.warning(
                            f"⚠️ {remaining_duplicates} "
                            f"duplicate row(s) remain"
                        )


                # ==================================================
                # DOWNLOAD
                # ==================================================

                st.subheader(
                    "⬇️ Download Cleaned Dataset"
                )


                csv_data = cleaned_df.to_csv(
                    index=False
                )


                st.download_button(
                    label="📥 Download Cleaned CSV",
                    data=csv_data,
                    file_name="cleaned_dataset.csv",
                    mime="text/csv"
                )


        # ==================================================
        # SHOW CURRENT CLEANED DATASET
        # ==================================================

        if st.session_state.cleaned:

            st.divider()

            st.subheader(
                "✨ Current Cleaned Dataset"
            )


            st.dataframe(
                st.session_state.df,
                use_container_width=True
            )


    # ==================================================
    # ERROR HANDLING
    # ==================================================

    except Exception as e:

        st.error(
            "❌ Error while reading or processing the file"
        )

        st.exception(e)


# ==================================================
# AI RECOMMENDED DASHBOARD
# ==================================================

if st.session_state.database_saved:

    st.divider()

    st.header("📊 AI Recommended Dashboard")

    st.write(
        "Gemini analyzes your dataset and recommends "
        "useful visualizations automatically."
    )


    # ==================================================
    # GENERATE DASHBOARD
    # ==================================================

    if st.button(
        "✨ Generate AI Dashboard",
        type="primary"
    ):

        with st.spinner(
            "🤖 Gemini is analyzing your dataset..."
        ):

            try:

                current_df = st.session_state.df

                recommendations = recommend_charts(
                    current_df
                )


                # Save recommendations
                st.session_state.chart_recommendations = (
                    recommendations
                )


                if recommendations:

                    st.success(
                        "✅ AI dashboard recommendations generated!"
                    )

                else:

                    st.warning(
                        "⚠️ Gemini did not recommend any charts."
                    )


            except Exception as chart_error:

                st.error(
                    "❌ Could not generate the AI dashboard."
                )

                error_message = str(chart_error)


                # Handle Gemini quota error
                if "429" in error_message or "quota" in error_message.lower():

                    st.warning(
                        "⚠️ Gemini API quota has been exceeded."
                    )

                    st.info(
                        "Please wait for the quota window to reset "
                        "before trying again."
                    )

                else:

                    st.exception(
                        chart_error
                    )


    # ==================================================
    # DISPLAY SAVED RECOMMENDATIONS
    # ==================================================

    recommendations = st.session_state.get(
        "chart_recommendations",
        []
    )


    if recommendations:

        current_df = st.session_state.df

        display_recommended_charts(
            current_df,
            recommendations
        )


# ==================================================
# AI DATA ANALYST
# ==================================================

if st.session_state.database_saved:

    st.divider()

    st.header(
        "🤖 AI Data Analyst"
    )

    st.write(
        "Ask questions about your uploaded dataset "
        "using natural language."
    )


    # ==================================================
    # EXAMPLE QUESTIONS
    # ==================================================

    st.subheader(
        "💡 Example Questions"
    )


    example_col1, example_col2 = st.columns(2)


    with example_col1:

        st.write(
            "• How many people are in the dataset?"
        )

        st.write(
            "• What is the average age?"
        )

        st.write(
            "• How many males are there?"
        )


    with example_col2:

        st.write(
            "• What are the different genders?"
        )

        st.write(
            "• What is the maximum age?"
        )

        st.write(
            "• What is the minimum age?"
        )


    # ==================================================
    # ASK AI
    # ==================================================

    st.subheader(
        "💬 Ask AI"
    )


    question = st.text_input(
        "Ask a question about your data:",
        placeholder="Example: What is the total amount?"
    )


    # ==================================================
    # ASK AI BUTTON
    # ==================================================

    if st.button(
        "🤖 Ask AI",
        type="primary"
    ):

        if not question.strip():

            st.warning(
                "⚠️ Please enter a question."
            )

        else:

            with st.spinner(
                "🤖 AI is analyzing your dataset..."
            ):

                try:

                    answer = sql_agent(
                        question,
                        st.session_state.get(
                            "table_name",
                            "orders"
                        )
                    )


                    st.subheader(
                        "💬 AI Answer"
                    )


                    st.success(
                        answer
                    )


                except Exception as ai_error:

                    st.error(
                        "❌ Could not answer the question."
                    )


                    error_message = str(ai_error)


                    # Handle Gemini quota error
                    if "429" in error_message or "quota" in error_message.lower():

                        st.warning(
                            "⚠️ Gemini API quota has been exceeded."
                        )

                        st.info(
                            "Please wait for the Gemini quota "
                            "to reset before trying again."
                        )

                    else:

                        st.exception(
                            ai_error
                        )