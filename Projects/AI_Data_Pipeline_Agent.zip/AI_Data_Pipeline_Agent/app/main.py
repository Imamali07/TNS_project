from fastapi import FastAPI
import pandas as pd
from src.database.database import engine

app = FastAPI()


def validate_data(df):
    errors = []

    # Check missing values
    missing_values = df.isnull().sum()

    for column, count in missing_values.items():
        if count > 0:
            errors.append(f"{column} has {count} missing value(s)")

    # Check duplicate rows
    duplicate_count = df.duplicated().sum()

    if duplicate_count > 0:
        errors.append(f"Found {duplicate_count} duplicate row(s)")

    # Check negative quantity
    if (df["quantity"] < 0).any():
        errors.append("Negative quantity found")

    # Check negative amount
    if (df["amount"] < 0).any():
        errors.append("Negative amount found")

    return errors


@app.get("/")
def home():
    return {"message": "AI Data Pipeline Agent is running"}


@app.post("/run-pipeline")
def run_pipeline():

    # 1. Load data
    df = pd.read_csv("data/orders.csv")

    # 2. Clean data
    df = df.drop_duplicates()
    df["customer_name"] = df["customer_name"].fillna("Unknown")
    df["order_date"] = pd.to_datetime(df["order_date"])

    # 3. Validate data
    errors = validate_data(df)

    if errors:
        return {
            "status": "failed",
            "message": "Data validation failed",
            "errors": errors
        }

    # 4. Store in PostgreSQL
    df.to_sql(
        "orders",
        engine,
        if_exists="replace",
        index=False
    )

    return {
        "status": "success",
        "message": "Data pipeline completed successfully",
        "rows": len(df)
    }