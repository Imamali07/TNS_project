"""
preprocessing.py
-----------------
Data cleaning and feature-engineering utilities for the Manufacturing
Equipment Output Prediction capstone project.

This module is imported by both the training notebook/script and the
FastAPI inference service so that training-time and inference-time
preprocessing never drift apart.
"""

import numpy as np
import pandas as pd

# Columns as described in the project brief
NUMERIC_FEATURES = [
    "Injection_Temperature",
    "Injection_Pressure",
    "Cycle_Time",
    "Cooling_Time",
    "Material_Viscosity",
    "Ambient_Temperature",
    "Machine_Age",
    "Operator_Experience",
    "Maintenance_Hours",
    "Temperature_Pressure_Ratio",
    "Total_Cycle_Time",
    "Efficiency_Score",
    "Machine_Utilization",
    "Hour",          # engineered from Timestamp
    "Month",         # engineered from Timestamp
]

CATEGORICAL_FEATURES = [
    "Shift",
    "Machine_Type",
    "Material_Grade",
    "Day_of_Week",
]

TARGET = "Parts_Per_Hour"

# Columns that have known missing values per the project brief
MISSING_VALUE_COLUMNS = [
    "Material_Viscosity",
    "Ambient_Temperature",
    "Operator_Experience",
]


def load_raw_data(csv_path: str) -> pd.DataFrame:
    """Load the raw manufacturing dataset from disk."""
    df = pd.read_csv(csv_path)
    return df


def engineer_time_features(df: pd.DataFrame) -> pd.DataFrame:
    """
    Convert the Timestamp column into useful numeric time features
    (Hour of day, Month) and drop the raw Timestamp column, since a raw
    datetime string carries no direct numeric signal for a linear model.
    """
    df = df.copy()
    df["Timestamp"] = pd.to_datetime(df["Timestamp"])
    df["Hour"] = df["Timestamp"].dt.hour
    df["Month"] = df["Timestamp"].dt.month
    df = df.drop(columns=["Timestamp"])
    return df


def remove_duplicates(df: pd.DataFrame) -> pd.DataFrame:
    """Remove exact duplicate rows."""
    before = len(df)
    df = df.drop_duplicates().reset_index(drop=True)
    after = len(df)
    if before != after:
        print(f"Removed {before - after} duplicate rows.")
    return df


def cap_outliers_iqr(df: pd.DataFrame, columns, factor: float = 1.5) -> pd.DataFrame:
    """
    Cap (winsorize) outliers in the given numeric columns using the
    1.5*IQR rule. Capping (rather than deleting rows) is used because the
    dataset is small (1000 rows) and each row also carries valid
    information in its other 16 features.
    """
    df = df.copy()
    for col in columns:
        q1 = df[col].quantile(0.25)
        q3 = df[col].quantile(0.75)
        iqr = q3 - q1
        lower = q1 - factor * iqr
        upper = q3 + factor * iqr
        n_outliers = ((df[col] < lower) | (df[col] > upper)).sum()
        if n_outliers > 0:
            df[col] = df[col].clip(lower=lower, upper=upper)
            print(f"Capped {n_outliers} outlier(s) in '{col}' to [{lower:.2f}, {upper:.2f}]")
    return df


def clean_dataset(raw_df: pd.DataFrame, outlier_cap: bool = True) -> pd.DataFrame:
    """
    Full cleaning pipeline (steps 3-7 of the project workflow):
      1. Drop/convert Timestamp -> Hour, Month
      2. Remove duplicate rows
      3. Cap statistical outliers in key numeric columns
    Missing-value imputation and encoding/scaling are handled separately
    inside the scikit-learn Pipeline (ColumnTransformer) so that they are
    fit ONLY on the training split (no data leakage) and are trivially
    reusable at inference time.
    """
    df = engineer_time_features(raw_df)
    df = remove_duplicates(df)

    if outlier_cap:
        # Columns identified during EDA as containing extreme, physically
        # implausible values (e.g. Material_Viscosity of 1000 cP against a
        # normal range of ~100-400 cP, Maintenance_Hours of 500 against a
        # normal range of ~26-76 hours).
        outlier_columns = [
            "Material_Viscosity",
            "Maintenance_Hours",
            "Injection_Temperature",
        ]
        df = cap_outliers_iqr(df, outlier_columns)

    return df


def split_features_target(df: pd.DataFrame):
    """Split a cleaned dataframe into X (features) and y (target)."""
    X = df[NUMERIC_FEATURES + CATEGORICAL_FEATURES].copy()
    y = df[TARGET].copy()
    return X, y
