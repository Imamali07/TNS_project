"""
train.py
--------
End-to-end training script for the Manufacturing Equipment Output
Prediction capstone project.

Run:
    python src/train.py

Produces:
    models/model.pkl                 -> best fitted sklearn Pipeline
                                         (preprocessing + regressor)
    models/model_metadata.json       -> metrics & metadata for the report
    visuals/*.png                    -> EDA and evaluation charts
"""

import json
import os
import sys

import joblib
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
from scipy import stats
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import Lasso, LinearRegression, Ridge
from sklearn.metrics import (
    mean_absolute_error,
    mean_absolute_percentage_error,
    mean_squared_error,
    r2_score,
)
from sklearn.model_selection import GridSearchCV, cross_val_score, train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.impute import SimpleImputer

sys.path.append(os.path.dirname(__file__))
from preprocessing import (
    CATEGORICAL_FEATURES,
    NUMERIC_FEATURES,
    TARGET,
    clean_dataset,
    load_raw_data,
    split_features_target,
)

sns.set_theme(style="whitegrid")
RANDOM_STATE = 42

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_PATH = os.path.join(BASE_DIR, "data", "manufacturing_dataset_1000_samples.csv")
VISUALS_DIR = os.path.join(BASE_DIR, "visuals")
MODELS_DIR = os.path.join(BASE_DIR, "models")
os.makedirs(VISUALS_DIR, exist_ok=True)
os.makedirs(MODELS_DIR, exist_ok=True)


def savefig(name):
    path = os.path.join(VISUALS_DIR, name)
    plt.tight_layout()
    plt.savefig(path, dpi=120, bbox_inches="tight")
    plt.close()
    print(f"Saved chart: {path}")


def run_eda(df: pd.DataFrame):
    """Generate and save the EDA visualizations used in the report/notebook."""

    # 1. Target distribution
    plt.figure(figsize=(7, 5))
    sns.histplot(df[TARGET], kde=True, color="#2c7fb8")
    plt.title("Distribution of Parts_Per_Hour (Target Variable)")
    plt.xlabel("Parts Per Hour")
    savefig("01_target_distribution.png")

    # 2. Correlation heatmap (numeric features vs target)
    plt.figure(figsize=(12, 9))
    numeric_cols = NUMERIC_FEATURES + [TARGET]
    corr = df[numeric_cols].corr()
    sns.heatmap(corr, annot=True, fmt=".2f", cmap="coolwarm", center=0, linewidths=0.5)
    plt.title("Correlation Heatmap - Numeric Features vs Parts_Per_Hour")
    savefig("02_correlation_heatmap.png")

    # 3. Top correlated features as scatter plots
    top_feats = corr[TARGET].drop(TARGET).abs().sort_values(ascending=False).head(4).index.tolist()
    fig, axes = plt.subplots(2, 2, figsize=(12, 9))
    for ax, feat in zip(axes.ravel(), top_feats):
        sns.regplot(x=df[feat], y=df[TARGET], ax=ax, scatter_kws={"alpha": 0.4, "s": 15}, line_kws={"color": "red"})
        ax.set_title(f"{feat} vs Parts_Per_Hour")
    plt.suptitle("Relationship Between Top Correlated Features and Output", y=1.02)
    savefig("03_top_feature_scatter.png")

    # 4. Categorical features vs target (boxplots)
    fig, axes = plt.subplots(2, 2, figsize=(13, 9))
    for ax, feat in zip(axes.ravel(), CATEGORICAL_FEATURES):
        order = df.groupby(feat)[TARGET].median().sort_values(ascending=False).index
        sns.boxplot(x=feat, y=TARGET, data=df, ax=ax, order=order, palette="Set2")
        ax.set_title(f"Parts_Per_Hour by {feat}")
        ax.tick_params(axis="x", rotation=30)
    plt.suptitle("Categorical Feature Impact on Output", y=1.02)
    savefig("04_categorical_boxplots.png")

    # 5. Outlier check - boxplots of key numeric columns (before capping shown separately in notebook)
    plt.figure(figsize=(12, 6))
    outlier_check_cols = ["Material_Viscosity", "Maintenance_Hours", "Injection_Temperature", "Operator_Experience"]
    df_melt = df[outlier_check_cols].melt(var_name="Feature", value_name="Value")
    sns.boxplot(x="Feature", y="Value", data=df_melt, palette="Set3")
    plt.title("Boxplots of Key Numeric Features (Outlier Check)")
    plt.xticks(rotation=15)
    savefig("05_outlier_boxplots.png")

    # 6. Cycle time vs output (strongest negative correlation)
    plt.figure(figsize=(7, 5))
    sns.scatterplot(x=df["Cycle_Time"], y=df[TARGET], hue=df["Machine_Type"], alpha=0.6)
    plt.title("Cycle Time vs Parts Per Hour (by Machine Type)")
    savefig("06_cycletime_vs_output.png")

    # 7. Pairwise relationships among efficiency-related features
    plt.figure(figsize=(7, 5))
    sns.scatterplot(x=df["Efficiency_Score"], y=df[TARGET], hue=df["Shift"], alpha=0.6)
    plt.title("Efficiency Score vs Parts Per Hour (by Shift)")
    savefig("07_efficiency_vs_output.png")


def build_preprocessor() -> ColumnTransformer:
    """Build the ColumnTransformer that imputes, scales, and encodes features."""
    numeric_pipeline = Pipeline(steps=[
        ("imputer", SimpleImputer(strategy="median")),
        ("scaler", StandardScaler()),
    ])

    categorical_pipeline = Pipeline(steps=[
        ("imputer", SimpleImputer(strategy="most_frequent")),
        ("onehot", OneHotEncoder(handle_unknown="ignore", drop="first")),
    ])

    preprocessor = ColumnTransformer(transformers=[
        ("num", numeric_pipeline, NUMERIC_FEATURES),
        ("cat", categorical_pipeline, CATEGORICAL_FEATURES),
    ])
    return preprocessor


def evaluate_model(name, model, X_test, y_test, results: dict):
    """Compute regression metrics for a fitted model and store + print them."""
    y_pred = model.predict(X_test)

    mse = mean_squared_error(y_test, y_pred)
    rmse = np.sqrt(mse)
    mae = mean_absolute_error(y_test, y_pred)
    r2 = r2_score(y_test, y_pred)
    mape = mean_absolute_percentage_error(y_test, y_pred) * 100
    # "Accuracy" for a regression task is not statistically defined the way
    # it is for classification; we report the standard regression proxy for
    # it, 100 - MAPE, so the secondary metric requested in the brief still
    # has a concrete, interpretable value.
    accuracy_proxy = max(0.0, 100 - mape)

    results[name] = {
        "MSE": mse,
        "RMSE": rmse,
        "MAE": mae,
        "R2": r2,
        "MAPE_%": mape,
        "Accuracy_proxy_%": accuracy_proxy,
    }
    print(f"\n{name}")
    print(f"  MSE   : {mse:.4f}")
    print(f"  RMSE  : {rmse:.4f}")
    print(f"  MAE   : {mae:.4f}")
    print(f"  R2    : {r2:.4f}")
    print(f"  MAPE  : {mape:.2f}%")
    return y_pred


def main():
    print("=" * 70)
    print("STEP 1-2: Load and inspect dataset")
    print("=" * 70)
    raw_df = load_raw_data(DATA_PATH)
    print(f"Raw shape: {raw_df.shape}")
    print(f"Missing values before cleaning:\n{raw_df.isnull().sum()[raw_df.isnull().sum() > 0]}")

    print("\n" + "=" * 70)
    print("STEP 3-7: Clean data, engineer features, handle duplicates/outliers")
    print("=" * 70)
    clean_df = clean_dataset(raw_df)
    print(f"Cleaned shape: {clean_df.shape}")

    print("\n" + "=" * 70)
    print("STEP 8-9: EDA")
    print("=" * 70)
    run_eda(clean_df)

    print("\n" + "=" * 70)
    print("STEP 10: Train/test split")
    print("=" * 70)
    X, y = split_features_target(clean_df)
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=RANDOM_STATE
    )
    print(f"Train: {X_train.shape}, Test: {X_test.shape}")

    preprocessor = build_preprocessor()

    print("\n" + "=" * 70)
    print("STEP 10-11: Build & compare candidate models")
    print("=" * 70)
    candidates = {
        "Linear Regression": LinearRegression(),
        "Ridge Regression": Ridge(random_state=RANDOM_STATE),
        "Lasso Regression": Lasso(random_state=RANDOM_STATE, max_iter=10000),
        "Random Forest Regressor": RandomForestRegressor(random_state=RANDOM_STATE, n_jobs=-1),
    }

    results = {}
    fitted_pipelines = {}
    for name, estimator in candidates.items():
        pipe = Pipeline(steps=[("preprocessor", preprocessor), ("model", estimator)])
        pipe.fit(X_train, y_train)
        fitted_pipelines[name] = pipe
        evaluate_model(name, pipe, X_test, y_test, results)
        cv_scores = cross_val_score(pipe, X_train, y_train, cv=5, scoring="r2")
        results[name]["CV_R2_mean"] = cv_scores.mean()
        results[name]["CV_R2_std"] = cv_scores.std()
        print(f"  5-fold CV R2: {cv_scores.mean():.4f} (+/- {cv_scores.std():.4f})")

    print("\n" + "=" * 70)
    print("STEP 12: Hyperparameter tuning (Ridge as primary linear model, "
          "Random Forest as benchmark)")
    print("=" * 70)

    ridge_pipe = Pipeline(steps=[("preprocessor", preprocessor), ("model", Ridge(random_state=RANDOM_STATE))])
    ridge_param_grid = {"model__alpha": [0.01, 0.1, 1.0, 5.0, 10.0, 50.0, 100.0]}
    ridge_grid = GridSearchCV(ridge_pipe, ridge_param_grid, cv=5, scoring="r2", n_jobs=-1)
    ridge_grid.fit(X_train, y_train)
    print(f"Best Ridge alpha: {ridge_grid.best_params_} | CV R2: {ridge_grid.best_score_:.4f}")
    evaluate_model("Ridge Regression (Tuned)", ridge_grid.best_estimator_, X_test, y_test, results)
    fitted_pipelines["Ridge Regression (Tuned)"] = ridge_grid.best_estimator_

    rf_pipe = Pipeline(steps=[("preprocessor", preprocessor), ("model", RandomForestRegressor(random_state=RANDOM_STATE, n_jobs=-1))])
    rf_param_grid = {
        "model__n_estimators": [200, 400],
        "model__max_depth": [None, 8, 12],
        "model__min_samples_leaf": [1, 3],
    }
    rf_grid = GridSearchCV(rf_pipe, rf_param_grid, cv=3, scoring="r2", n_jobs=-1)
    rf_grid.fit(X_train, y_train)
    print(f"Best RF params: {rf_grid.best_params_} | CV R2: {rf_grid.best_score_:.4f}")
    evaluate_model("Random Forest (Tuned)", rf_grid.best_estimator_, X_test, y_test, results)
    fitted_pipelines["Random Forest (Tuned)"] = rf_grid.best_estimator_

    print("\n" + "=" * 70)
    print("STEP 13: Model comparison & selection")
    print("=" * 70)
    results_df = pd.DataFrame(results).T.sort_values("R2", ascending=False)
    print(results_df.round(4))

    # The project explicitly calls for a LINEAR REGRESSION model as the
    # primary deliverable. We therefore select the best-performing LINEAR
    # model (Linear / Ridge / Lasso) as the final production model, while
    # reporting Random Forest only as a non-linear benchmark for context.
    linear_candidates = {k: v for k, v in results.items() if "Forest" not in k}
    best_linear_name = max(linear_candidates, key=lambda k: linear_candidates[k]["R2"])
    best_model_pipeline = fitted_pipelines[best_linear_name]
    print(f"\nSelected final model (best linear model): {best_linear_name}")

    # Comparison chart
    plt.figure(figsize=(10, 6))
    plot_df = results_df.reset_index().rename(columns={"index": "Model"})
    sns.barplot(x="R2", y="Model", data=plot_df, palette="viridis")
    plt.title("Model Comparison - R2 Score (Test Set)")
    plt.xlabel("R2 Score")
    savefig("08_model_comparison_r2.png")

    plt.figure(figsize=(10, 6))
    sns.barplot(x="RMSE", y="Model", data=plot_df, palette="magma")
    plt.title("Model Comparison - RMSE (Test Set)")
    plt.xlabel("RMSE (Parts Per Hour)")
    savefig("09_model_comparison_rmse.png")

    print("\n" + "=" * 70)
    print("STEP 13: Residual diagnostics for the final model")
    print("=" * 70)
    y_pred_final = best_model_pipeline.predict(X_test)
    residuals = y_test - y_pred_final

    fig, axes = plt.subplots(1, 2, figsize=(13, 5))
    axes[0].scatter(y_pred_final, residuals, alpha=0.5, color="#2c7fb8")
    axes[0].axhline(0, color="red", linestyle="--")
    axes[0].set_xlabel("Predicted Parts_Per_Hour")
    axes[0].set_ylabel("Residuals")
    axes[0].set_title("Residuals vs Predicted Values")

    stats.probplot(residuals, dist="norm", plot=axes[1])
    axes[1].set_title("Q-Q Plot of Residuals")
    savefig("10_residual_diagnostics.png")

    plt.figure(figsize=(7, 6))
    plt.scatter(y_test, y_pred_final, alpha=0.5, color="#2c7fb8")
    lims = [min(y_test.min(), y_pred_final.min()), max(y_test.max(), y_pred_final.max())]
    plt.plot(lims, lims, "r--", label="Perfect Prediction")
    plt.xlabel("Actual Parts_Per_Hour")
    plt.ylabel("Predicted Parts_Per_Hour")
    plt.title(f"Actual vs Predicted - {best_linear_name}")
    plt.legend()
    savefig("11_actual_vs_predicted.png")

    # Feature importance (coefficients) for the final linear model
    try:
        ohe_cols = best_model_pipeline.named_steps["preprocessor"].transformers_[1][1].named_steps["onehot"].get_feature_names_out(CATEGORICAL_FEATURES)
        feature_names = NUMERIC_FEATURES + list(ohe_cols)
        coefs = best_model_pipeline.named_steps["model"].coef_
        coef_df = pd.DataFrame({"Feature": feature_names, "Coefficient": coefs})
        coef_df["AbsCoefficient"] = coef_df["Coefficient"].abs()
        coef_df = coef_df.sort_values("AbsCoefficient", ascending=False).head(15)

        plt.figure(figsize=(9, 8))
        colors = ["#d73027" if c < 0 else "#1a9850" for c in coef_df["Coefficient"]]
        plt.barh(coef_df["Feature"][::-1], coef_df["Coefficient"][::-1], color=colors[::-1])
        plt.axvline(0, color="black", linewidth=0.8)
        plt.title(f"Top 15 Standardized Feature Coefficients - {best_linear_name}")
        plt.xlabel("Coefficient (impact on Parts_Per_Hour)")
        savefig("12_feature_coefficients.png")
    except Exception as e:
        print(f"Skipping coefficient plot (model has no linear coefficients): {e}")

    print("\n" + "=" * 70)
    print("STEP 14: Save final trained model")
    print("=" * 70)
    model_path = os.path.join(MODELS_DIR, "model.pkl")
    joblib.dump(best_model_pipeline, model_path)
    print(f"Saved model pipeline to {model_path}")

    metadata = {
        "final_model_name": best_linear_name,
        "target_variable": TARGET,
        "numeric_features": NUMERIC_FEATURES,
        "categorical_features": CATEGORICAL_FEATURES,
        "train_size": len(X_train),
        "test_size": len(X_test),
        "metrics": {k: {mk: (float(mv) if not isinstance(mv, str) else mv) for mk, mv in v.items()} for k, v in results.items()},
        "best_params": {
            "ridge_alpha": ridge_grid.best_params_.get("model__alpha") if "Ridge" in best_linear_name else None,
        },
    }
    metadata_path = os.path.join(MODELS_DIR, "model_metadata.json")
    with open(metadata_path, "w") as f:
        json.dump(metadata, f, indent=2)
    print(f"Saved metadata to {metadata_path}")

    results_df.round(4).to_csv(os.path.join(MODELS_DIR, "model_comparison_results.csv"))
    print("Saved model comparison table to models/model_comparison_results.csv")

    print("\nTraining pipeline complete.")
    return best_linear_name, results_df


if __name__ == "__main__":
    main()
