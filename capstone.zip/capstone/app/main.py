"""
FastAPI deployment service for the Manufacturing Equipment Output
Prediction model.

Run locally:
    uvicorn app.main:app --reload --host 0.0.0.0 --port 8000

Then open http://localhost:8000/docs for interactive Swagger UI.
"""

import json
import os

import joblib
import pandas as pd
from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
MODEL_PATH = os.path.join(BASE_DIR, "models", "model.pkl")
METADATA_PATH = os.path.join(BASE_DIR, "models", "model_metadata.json")
STATIC_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "static")

app = FastAPI(
    title="Manufacturing Output Prediction API",
    description="Predicts hourly injection-molding machine output (Parts_Per_Hour) "
                 "from machine operating parameters using a trained Linear Regression pipeline.",
    version="1.0.0",
)

app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")

# Load model and metadata once at startup
model = joblib.load(MODEL_PATH)
with open(METADATA_PATH) as f:
    metadata = json.load(f)


class MachineInput(BaseModel):
    Injection_Temperature: float = Field(..., example=215.0, description="Injection temperature (deg C)")
    Injection_Pressure: float = Field(..., example=116.0, description="Injection pressure (bar)")
    Cycle_Time: float = Field(..., example=35.0, description="Cycle time (seconds)")
    Cooling_Time: float = Field(..., example=12.0, description="Cooling time (seconds)")
    Material_Viscosity: float = Field(..., example=250.0, description="Material viscosity (cP)")
    Ambient_Temperature: float = Field(..., example=23.0, description="Ambient temperature (deg C)")
    Machine_Age: float = Field(..., example=7.0, description="Machine age (years)")
    Operator_Experience: float = Field(..., example=25.0, description="Operator experience (months)")
    Maintenance_Hours: float = Field(..., example=50.0, description="Hours since last maintenance")
    Temperature_Pressure_Ratio: float = Field(..., example=1.85, description="Injection_Temperature / Injection_Pressure")
    Total_Cycle_Time: float = Field(..., example=47.0, description="Cycle_Time + Cooling_Time")
    Efficiency_Score: float = Field(..., example=0.55, description="Composite machine efficiency score (0-1)")
    Machine_Utilization: float = Field(..., example=0.6, description="Machine utilization ratio (0-1)")
    Hour: int = Field(..., ge=0, le=23, example=14, description="Hour of day (0-23), derived from Timestamp")
    Month: int = Field(..., ge=1, le=12, example=6, description="Month (1-12), derived from Timestamp")
    Shift: str = Field(..., example="Day", description="One of: Day, Evening, Night")
    Machine_Type: str = Field(..., example="Type_A", description="One of: Type_A, Type_B, Type_C")
    Material_Grade: str = Field(..., example="Standard", description="One of: Economy, Standard, Premium")
    Day_of_Week: str = Field(..., example="Monday", description="Day name, e.g. Monday")


class PredictionResponse(BaseModel):
    predicted_parts_per_hour: float
    model_name: str


@app.get("/")
def root():
    """Serves the interactive control-panel dashboard."""
    return FileResponse(os.path.join(STATIC_DIR, "index.html"))


@app.get("/api")
def api_info():
    return {
        "message": "Manufacturing Output Prediction API is running.",
        "docs": "/docs",
        "dashboard": "/",
        "model": metadata.get("final_model_name"),
    }


@app.get("/health")
def health_check():
    return {"status": "ok"}


@app.get("/model-info")
def model_info():
    return {
        "model_name": metadata.get("final_model_name"),
        "target_variable": metadata.get("target_variable"),
        "numeric_features": metadata.get("numeric_features"),
        "categorical_features": metadata.get("categorical_features"),
        "test_metrics": metadata.get("metrics", {}).get(metadata.get("final_model_name"), {}),
    }


@app.post("/predict", response_model=PredictionResponse)
def predict(payload: MachineInput):
    try:
        input_df = pd.DataFrame([payload.dict()])
        prediction = model.predict(input_df)[0]
        return PredictionResponse(
            predicted_parts_per_hour=round(float(prediction), 2),
            model_name=metadata.get("final_model_name", "unknown"),
        )
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc))
