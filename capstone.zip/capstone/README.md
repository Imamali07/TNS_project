# Manufacturing Equipment Output Prediction — Linear Regression Capstone

Predict hourly injection-molding machine output (`Parts_Per_Hour`) from machine operating
parameters (temperature, pressure, cycle time, material properties, operator, shift, etc.)
using Linear Regression, so the production team can optimize machine settings, plan
schedules, and flag underperforming machines.

## Project Structure

```
capstone/
├── data/
│   └── manufacturing_dataset_1000_samples.csv   # raw dataset (1000 rows, 19 cols)
├── notebooks/
│   └── Capstone_Manufacturing_Linear_Regression.ipynb   # full, executed EDA + modeling notebook
├── src/
│   ├── preprocessing.py     # reusable cleaning / feature engineering functions
│   └── train.py              # end-to-end training script (mirrors the notebook)
├── models/
│   ├── model.pkl                      # final trained sklearn Pipeline (preprocessing + Linear Regression)
│   ├── model_metadata.json            # feature lists, metrics, chosen model name
│   └── model_comparison_results.csv   # metrics for every candidate model
├── app/
│   ├── main.py        # FastAPI inference service
│   └── Dockerfile      # container image definition
├── visuals/             # all EDA & evaluation charts (PNG), also embedded in the notebook
├── reports/
│   └── Project_Report.docx   # detailed written report (methodology, insights, results)
├── presentation/
│   └── Capstone_Presentation.pptx   # 15-20 slide stakeholder presentation
├── requirements.txt
├── docker-compose.yml
├── .dockerignore
└── README.md
```

## Dataset

- **Source:** `manufacturing_dataset_1000_samples.csv`
- **Records:** 1000
- **Target:** `Parts_Per_Hour` (continuous — hourly machine output)
- **Features (17):** Injection_Temperature, Injection_Pressure, Cycle_Time, Cooling_Time,
  Material_Viscosity, Ambient_Temperature, Machine_Age, Operator_Experience,
  Maintenance_Hours, Shift, Machine_Type, Material_Grade, Day_of_Week,
  Temperature_Pressure_Ratio, Total_Cycle_Time, Efficiency_Score, Machine_Utilization,
  plus `Timestamp` (converted into `Hour` and `Month`).

## Methodology Summary

1. **Cleaning:** `Timestamp` → engineered `Hour` / `Month`; duplicates removed (none found);
   1.5×IQR capping applied to `Material_Viscosity`, `Maintenance_Hours`, `Injection_Temperature`
   outliers.
2. **Missing values:** `Material_Viscosity`, `Ambient_Temperature`, `Operator_Experience`
   (20 missing each) — median imputation (numeric), fit only on the training split via
   `ColumnTransformer` to avoid data leakage.
3. **Encoding:** One-hot encoding (`drop="first"`) for `Shift`, `Machine_Type`,
   `Material_Grade`, `Day_of_Week`.
4. **Scaling:** `StandardScaler` on all numeric features.
5. **Modeling:** Linear Regression, Ridge, Lasso, and a Random Forest benchmark, compared
   with 5-fold cross-validation; Ridge/Random Forest hyperparameters tuned with `GridSearchCV`.
6. **Final model:** **Linear Regression** (best-performing linear model, per the project's
   explicit requirement to deliver a linear regression solution).

## Results

| Model | R² | RMSE | MAE | MAPE |
|---|---|---|---|---|
| **Linear Regression (final)** | **0.916** | **3.31** | **2.64** | **11.5%** |
| Ridge Regression (tuned) | 0.916 | 3.31 | 2.64 | 11.5% |
| Random Forest (tuned) | 0.854 | 4.37 | 3.44 | 13.6% |
| Lasso Regression | 0.815 | 4.91 | 3.91 | 15.8% |

*(Full table with cross-validation scores: `models/model_comparison_results.csv`)*

> **Note on evaluation metrics:** The original brief listed Recall/Precision/F1/Accuracy as
> primary metrics. These are classification metrics and do not apply to this regression
> task (continuous target). We report the statistically correct regression metrics
> (RMSE, MSE, MAE, R², MAPE) and provide an "accuracy proxy" (`100 - MAPE`) for
> stakeholders expecting a single accuracy-style percentage.

## Installation

```bash
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

## Running the Project

### 1. Retrain the model from scratch
```bash
python src/train.py
```
This regenerates `models/model.pkl`, `models/model_metadata.json`, and all charts in `visuals/`.

### 2. Explore the full analysis (recommended)
```bash
jupyter notebook notebooks/Capstone_Manufacturing_Linear_Regression.ipynb
```

### 3. Run the prediction API locally
```bash
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```
Open **http://localhost:8000/docs** for interactive Swagger UI.

Example request:
```bash
curl -X POST http://localhost:8000/predict \
  -H "Content-Type: application/json" \
  -d '{
    "Injection_Temperature": 215.0, "Injection_Pressure": 116.0,
    "Cycle_Time": 35.0, "Cooling_Time": 12.0, "Material_Viscosity": 250.0,
    "Ambient_Temperature": 23.0, "Machine_Age": 7.0, "Operator_Experience": 25.0,
    "Maintenance_Hours": 50.0, "Temperature_Pressure_Ratio": 1.85,
    "Total_Cycle_Time": 47.0, "Efficiency_Score": 0.55, "Machine_Utilization": 0.6,
    "Hour": 14, "Month": 6, "Shift": "Day", "Machine_Type": "Type_A",
    "Material_Grade": "Standard", "Day_of_Week": "Monday"
  }'
```
Response: `{"predicted_parts_per_hour": 39.3, "model_name": "Linear Regression"}`

### 4. Run with Docker
```bash
docker build -f app/Dockerfile -t manufacturing-output-api .
docker run -p 8000:8000 manufacturing-output-api
```
or with docker-compose:
```bash
docker compose up --build
```

## API Endpoints

| Method | Path | Description |
|---|---|---|
| GET | `/` | Service info |
| GET | `/health` | Health check |
| GET | `/model-info` | Model name, features, test-set metrics |
| POST | `/predict` | Predict `Parts_Per_Hour` from machine parameters |

## Libraries Used

Python, Pandas, NumPy, Matplotlib, Seaborn, Scikit-learn, SciPy, FastAPI, Uvicorn,
Pydantic, Joblib, Docker (see `requirements.txt` for pinned versions).

## Assumptions Made

1. **`Machine_Type` has 3 categories** (`Type_A`, `Type_B`, `Type_C`) in the actual data,
   not 2 as implied by the brief's text — all 3 are treated as valid categories.
2. **Evaluation metrics:** Recall/Precision/F1/Accuracy from the brief are classification
   metrics; since the target is continuous, regression metrics (RMSE, MSE, MAE, R², MAPE)
   are used instead, with an accuracy-proxy for stakeholder familiarity.
3. **Outlier handling:** capping (1.5×IQR winsorization) was used instead of row deletion
   to preserve dataset size (1000 rows) and the other valid feature values in affected rows.
4. **`Operator_Experience` up to 120 (months)** was treated as valid, not an outlier, since
   it is a physically plausible tenure value.
5. **Final model selection:** among Linear/Ridge/Lasso/Random Forest, the best-performing
   *linear* model was chosen as the production model, per the project's explicit requirement
   for a Linear Regression solution — Random Forest is reported only as a benchmark.
